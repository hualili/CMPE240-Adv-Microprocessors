#include "lcd__api.h"
#include "board.h"

int main(void)
{
	board_init();

	ssp0_init();

	lcd_init();

	// fill background color with WHITE color
	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, WHITE);

	// set draw pixel coordinates
	int x0,x1,y0,y1;

	x0 = 20;
	x1 = 80;
	y0 = 60;
	y1 = 140;

	drawLine(x0,y0,x1,y1,PURPLE);

	while (1) {}
	return 0;
}
